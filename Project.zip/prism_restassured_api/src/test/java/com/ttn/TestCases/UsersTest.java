package com.ttn.TestCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ttn.Builder.BaseTest;

import com.ttn.BusinessLogic.Users_GET;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UsersTest extends BaseTest{
	
	@Test(groups = {"Sanity"})
	public void usersTestValid()
	{
		Users_GET.UsersList();
		Assert.assertEquals(Users_GET.statusCode, 200);
		Assert.assertEquals(Users_GET.statusLine, "HTTP/1.1 200 OK");
		logger.info("Assert Passed");
		Assert.assertEquals(Users_GET.userListCount, 10);
		Assert.assertEquals(Users_GET.firstUserName, "Leanne Graham");
	}
	
	@Test
	public void usersTestInvalid()
	{
		Users_GET.UsersList();
		Assert.assertEquals(Users_GET.statusCode, 200);
		Assert.assertEquals(Users_GET.statusLine, "HTTP/1.1 200 OK");
		Assert.assertEquals(Users_GET.userListCount, 10);
		Assert.assertEquals(Users_GET.firstUserName, "ABC");
	}
	protected static Logger logger = LoggerFactory.getLogger(UsersTest.class);


}
