package com.ttn.TestCases;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ttn.BusinessLogic.Login;
import com.ttn.CommonUtils.ExcelReader;
import com.ttn.Builder.BaseTest;

public class LoginTest extends BaseTest {
	
    @Test(groups = {"Sanity"})
    public void logIn_Correct_SID_Password() throws EncryptedDocumentException, IOException
    {

 
        Login.loginWithPassword((ExcelReader.read_data("Login with Password",2,3)),(ExcelReader.read_data("Login with Password",3,3)));
        Assert.assertEquals(Login.code, 0);
        Assert.assertEquals(Login.message,"Logged in successfully.");
    }

    
	  @Test(priority=1) 
	  public void logIn_blankPassword() throws EncryptedDocumentException, IOException
	  {
	//	  test = extent.createTest("logIn_Correct_SID_Password");
	  Login.loginWithPassword((ExcelReader.read_data("Login with Password",2,4)),(ExcelReader.read_data("Login with Password",3,4)));
	  Assert.assertEquals(Login.code, 1014);
	  Assert.assertEquals(Login.message,"Password cannot be left empty."); 
	  }
	 
        
    @Test(priority=2)
    
        public void logIn_blank_SID() throws EncryptedDocumentException, IOException
    {
    //	test = extent.createTest("logIn_Correct_SID_Password");
            Login.loginWithPassword((ExcelReader.read_data("Login with Password",2,5)),(ExcelReader.read_data("Login with Password",3,5)));
            Assert.assertEquals(Login.code, 1002);
            Assert.assertEquals(Login.message,"Subscriber id cannot be left empty.");   
     }
     
    @Test(priority=3)

     public void logIn_Incorrect_SID_Correct_Password() throws EncryptedDocumentException, IOException, InterruptedException
    {
    	//Adding Sleep - as login api has some limitation related to number of hit in a minute
    	Thread.sleep(60000L);
    //	test = extent.createTest("logIn_Correct_SID_Password");
         Login.loginWithPassword((ExcelReader.read_data("Login with Password",2,6)),(ExcelReader.read_data("Login with Password",3,6)));
         Assert.assertEquals(Login.code, 1010);
         Assert.assertEquals(Login.message,"Subscriber id must be of 10 digits.");   
  }
        
    @Test(priority=4)

     public void logIn_Correct_SID_Inorrect_Password() throws EncryptedDocumentException, IOException
    {
    //	test = extent.createTest("logIn_Correct_SID_Password");
         Login.loginWithPassword((ExcelReader.read_data("Login with Password",2,7)),(ExcelReader.read_data("Login with Password",3,7)));
         Assert.assertEquals(Login.code, 3003);
         Assert.assertEquals(Login.message,"Please enter valid password.");   
  } 
        
    @Test(priority=5)

     public void logIn_Blank_SID_Blank_Password() throws EncryptedDocumentException, IOException
    {
    //	test = extent.createTest("logIn_Correct_SID_Password");
         Login.loginWithPassword((ExcelReader.read_data("Login with Password",2,8)),(ExcelReader.read_data("Login with Password",3,8)));
         Assert.assertEquals(Login.code, 1002);
         Assert.assertEquals(Login.message,"Subscriber id cannot be left empty.");   
  } 
    
  
}
