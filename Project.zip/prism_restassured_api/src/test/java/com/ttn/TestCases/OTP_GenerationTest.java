package com.ttn.TestCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ttn.Builder.BaseTest;
import com.ttn.BusinessLogic.OTP_Generation;

public class OTP_GenerationTest extends BaseTest {
	
	@Test(groups = {"Sanity"})
	//OTP generation with SID test case
	public void otpGenerationWithSID()
	{
	//	test = extent.createTest("OTP Generation with SID Test");
		OTP_Generation.otpGenerationWithSID();
		Assert.assertEquals(OTP_Generation.statusCode, 200);
		Assert.assertEquals(OTP_Generation.message,"OTP generated successfully.");
		//Log.info("Generated OTP via SID Successfully.");
	}
	
	
	@Test
	public void otpGenerationWithSID_InvalidMethod_POST()
	{
		//test = extent.createTest("OTP Generation RMN with invaid http method POST");
		OTP_Generation.otpGenerationWithSID_withInvalidhttpMethods("POST");
		Assert.assertEquals(OTP_Generation.statusCode, 405);
		Assert.assertEquals(OTP_Generation.message, "Request method 'POST' not supported");
		Assert.assertEquals(OTP_Generation.error_msg, "Method Not Allowed");

	}
	@Test
	public void otpGenerationWithSID_InvalidMethod_PUT()
	{
		//test = extent.createTest("OTP Generation RMN with invaid http method PUT");
		OTP_Generation.otpGenerationWithSID_withInvalidhttpMethods("PUT");
		Assert.assertEquals(OTP_Generation.statusCode, 405);
		Assert.assertEquals(OTP_Generation.message, "Request method 'PUT' not supported");
		Assert.assertEquals(OTP_Generation.error_msg, "Method Not Allowed");

	}
	@Test
	public void otpGenerationWithSID_InvalidMethod_PATCH()
	{
		//test = extent.createTest("OTP Generation RMN with invaid http method PATCH");
		OTP_Generation.otpGenerationWithSID_withInvalidhttpMethods("PATCH");
		Assert.assertEquals(OTP_Generation.statusCode, 405);
		Assert.assertEquals(OTP_Generation.message, "Request method 'PATCH' not supported");
		Assert.assertEquals(OTP_Generation.error_msg, "Method Not Allowed");

	}
	@Test
	public void otpGenerationWithSID_InvalidMethod_DELETE()
	{
		//test = extent.createTest("OTP Generation RMN with invaid http method DELETE");
		OTP_Generation.otpGenerationWithSID_withInvalidhttpMethods("DELETE");
		Assert.assertEquals(OTP_Generation.statusCode, 405);
		Assert.assertEquals(OTP_Generation.message, "Request method 'DELETE' not supported");
		Assert.assertEquals(OTP_Generation.error_msg, "Method Not Allowed");

	}
	
	
	
	
	
}
