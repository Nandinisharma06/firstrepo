package com.ttn.BusinessLogic;


import org.json.simple.JSONObject;

import com.ttn.Builder.RequestBuilder_new;
import com.ttn.CommonUtils.ExtentManager;
import com.ttn.CommonUtils.PropertyReader;
import com.ttn.Builder.BaseTest;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Login{
	
	 private static JSONObject requestParam;
	  public static Response response;
	    public static int  statusCode;
	    public static String  message;
	    public static int code ;
	  //Replace below end point as per need.
	    private static String  endpoint = "/dummy/Login";
	    
	    public static void loginWithPassword(String username, String password) {
	    	
	    	RequestBuilder_new.getBase_URL();
	    	
	        requestParam = new JSONObject();
	        requestParam.put("sid", username);
	        requestParam.put("pwd", password);
	        RequestBuilder_new.request.header("Content-Type", "application/json");
	        RequestBuilder_new.request.body(requestParam.toJSONString());
	        response =  RequestBuilder_new.request.post(endpoint);
	        ExtentManager.responseBody = response.getBody().asString();
	        ExtentManager.ApiInfo = endpoint;
	        message =   response.jsonPath().get("message").toString();
	        code =   response.jsonPath().get("code");
	    }

}
