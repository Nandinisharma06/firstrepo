package com.ttn.BusinessLogic;

import java.util.ArrayList;

import com.ttn.Builder.RequestBuilder_new;
import com.ttn.CommonUtils.ExtentManager;
import com.ttn.CommonUtils.PropertyReader;

import io.restassured.http.Method;
import io.restassured.response.Response;

public class Users_GET {
	
	 private static Response response;
	  public static int statusCode;
	  public static String  firstUserName;
	  public static String statusLine;
	  public static int  userListCount;
	  public static int code;
	  private static String  endpoint = "/users";
	
	public static void UsersList()
	{
		RequestBuilder_new.getBase_URL();

       RequestBuilder_new.request.header("Content-Type", "application/json");
       response = RequestBuilder_new.request.request(Method.GET, endpoint);
       ExtentManager.ApiInfo = endpoint;
       ExtentManager.responseBody = response.getBody().asString();
       statusCode = response.getStatusCode();
       statusLine=  response.getStatusLine();
       ArrayList<String> meta =   response.jsonPath().get("name");
      userListCount = meta.size();
      firstUserName = meta.get(0);
}

}
