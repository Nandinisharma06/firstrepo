package com.ttn.BusinessLogic;


import com.ttn.Builder.RequestBuilder_new;
import com.ttn.CommonUtils.ExtentManager;
import com.ttn.CommonUtils.HttpMethodSelector;
import com.ttn.CommonUtils.PropertyReader;

import io.restassured.http.Method;
import io.restassured.response.Response;

public class OTP_Generation {
	
	  private static Response response;
	  public static int statusCode;
	  public static String  message;
	  public static String error_msg;
	  public static int code;
	  private static String SID = PropertyReader.getProperty("SID");
	  private static String  endpoint = "/dummy/ABC";
	
	public static void otpGenerationWithSID()
	{
		RequestBuilder_new.getBase_URL();

        RequestBuilder_new.request.header("Content-Type", "application/json");
        String final_endpoint = endpoint+SID+"/otp";
        response = RequestBuilder_new.request.request(Method.GET, final_endpoint);
        ExtentManager.ApiInfo = final_endpoint;
        ExtentManager.responseBody = response.getBody().asString();
        statusCode = response.getStatusCode();
        message = response.jsonPath().get("message").toString();
       
        
	}
	
	//OTP Generation with SID -->Invalid http Methods
		public static void otpGenerationWithSID_withInvalidhttpMethods(String httpMethod)
		{
			RequestBuilder_new.getBase_URL();

			RequestBuilder_new.request.header("Content-Type", "application/json");
			 String final_endpoint = endpoint+SID+"/otp";
			HttpMethodSelector.httpMethodSelector(httpMethod,final_endpoint);
			
			ExtentManager.ApiInfo = final_endpoint;
			 ExtentManager.responseBody = HttpMethodSelector.response.getBody().asString();

			statusCode = HttpMethodSelector.response.getStatusCode();
			message =   HttpMethodSelector.response.jsonPath().get("message").toString();
			error_msg = HttpMethodSelector.response.jsonPath().get("error").toString();
			
			
		}
	
	

}
