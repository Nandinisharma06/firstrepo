package com.ttn.Builder;
/**
 * 
 * @author TTN
 */

import com.ttn.CommonUtils.PropertyReader;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class RequestBuilder_new {
	
	public static RequestSpecification request;
	 public static String Environment=PropertyReader.getProperty_for_baseconfig("Environment");

    public static String Prod_Base_Url=PropertyReader.getProperty_for_baseconfig("Prod_Base_Url");
    public static String Stage_Base_Url=PropertyReader.getProperty_for_baseconfig("Stage_Base_Url");
    public static String UAT_Base_Url=PropertyReader.getProperty_for_baseconfig("UAT_Base_Url");

    public static void getBase_URL() {
    	
    	if(Environment.equalsIgnoreCase("UAT"))
    	{
        	RestAssured.baseURI = UAT_Base_Url;
      	    request = RestAssured.given();   	
      	
    	}
    	else if(Environment.equalsIgnoreCase("Stage"))
    	{
        	RestAssured.baseURI = Prod_Base_Url;
      	    request = RestAssured.given();  
      	
    	}
    	else if(Environment.equalsIgnoreCase("prod"))
    	{
        	RestAssured.baseURI = Prod_Base_Url;
      	    request = RestAssured.given();   
      	 
    	}

  	   }
    
    
    
    
}