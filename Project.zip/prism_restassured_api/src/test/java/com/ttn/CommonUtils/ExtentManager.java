package com.ttn.CommonUtils;


public class ExtentManager {

	 public static String responseBody;
	 public static String ApiInfo;
	 
	 
	 // To add Response body in report
    public static String getResponseBody()
    {
   
    	return responseBody;
    }
    
 // To add API Information in report
    public static String getApiInfo()
    {
   
    	return ApiInfo; 
    }
    

    }

